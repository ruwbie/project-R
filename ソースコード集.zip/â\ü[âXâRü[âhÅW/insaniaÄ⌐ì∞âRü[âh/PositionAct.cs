﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//==============================================================================================================
//=====スクリプトの説明===========================================================================================

// TagにPlayerと設定されているGameobjectを探して、このスクリプトがアッタッチされたObjectとPlayerの距離を図る。
//  一定以上近づいたら、this.AudioSourceに設定している音がなる。
//  
//  このスクリプトを付けたObject、探すGameobjectのTag、AudioSourceの設定を変えることで　修正可能。
//  応用として、音以外のものも動かせる
//===============================================================================================================

//★★★★★　https://qiita.com/su10/items/516ddd4a08429be9c42b　★★★★★//詳しくはこのページに乗っている
public class PositionAct : MonoBehaviour
{
    //☆☆Unityで変更する要素☆☆//
    GameObject higaisia;
    //float DX;
    //float DZ;
    //float DR;
    bool Isplayed;
    bool triggerOn;
    bool createCollider;
    float frame;
    //☆☆初期化☆☆//
    void Start()
    {
        higaisia = GameObject.FindGameObjectWithTag("Player");
        if (higaisia)
        {
            Debug.Log(higaisia.tag);
        }
        else
        {
            Debug.Log("No game object called player found");
        }
        Isplayed = false;
        triggerOn = false;
        createCollider = false;
        frame = 0;

    }
    //☆☆更新☆☆//
    void Update()
    {
        higaisia = GameObject.FindGameObjectWithTag("Player");
        if(triggerOn == true)
        {
            frame += Time.deltaTime *1.0f ;
            if (frame >= 0.5f && createCollider == false)
            {
                if(createCollider == true) { return; }
                this.gameObject.AddComponent<BoxCollider>();
                this.gameObject.AddComponent<Rigidbody>();
                createCollider = true;
            }

            if (Isplayed == false && frame >= 1.0f)
            {
                this.GetComponentInChildren<AudioSource>().Play();
                Isplayed = true;
            }

            if(frame >= 3.5f)
            {
                Destroy(this.gameObject.transform.parent.gameObject);
                Destroy(this.gameObject);
            }
        }
    }
    
    private void OnTriggerEnter(Collider collision)
    {
        if(collision.gameObject.tag == higaisia.tag)
        {
            triggerOn = true;
            //Destroy(collision);
        }
    }
    
}


