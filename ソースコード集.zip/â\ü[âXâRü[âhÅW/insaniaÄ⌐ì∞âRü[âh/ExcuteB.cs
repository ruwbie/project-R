﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
* 作成者：      ウ
* 更新日：      
* 最終更新者：  
* 概要：        
* アタッチ先：  
* 補足：        
*/


public class ExcuteB : MonoBehaviour
{


    private Transform playertr;
    //private UnityEngine.AI.NavMeshAgent nvAgent;


    AnimatorStateInfo currentAnimatorInfo;
    Animator think;

    float speed = 1.0f;

    public float ViewAngle;    //視野角
    public float ViewDistance; //視野の届く距離
    public float AttackRange;   //攻撃の範囲

    public LayerMask TargetMask;    //Enemy マスク指定の為の変数
    public LayerMask ObstacleMask;  //妨害物のマスク指定のの変数
                                    //消したい場合は!Physics.Raycastの引数の内、ObstacleMaskを０にしてこの変数を消す。

    private Transform _transform;

    public GameObject deleteEffect;//消滅時のエフェクト
    //public GameObject bloodSpray;//血しぶき
    //public GameObject AttackEffect;//攻撃時のエフェクト
    public float AttackEffectTime;//攻撃のタイミング

    AudioSource audioSource;//親のオーディオソースを入れる
    public AudioClip[] audioClips;// 1.召喚  ;2.歩き  ;3脅かし

    public bool start;
    bool flag;

    // Use this for initialization
    void Start()
    {
        playertr = GameObject.FindWithTag("Dog").GetComponent<Transform>();
        _transform = GetComponent<Transform>();
        think = this.GetComponent<Animator>();
        //親のオーディオソースの取得
        audioSource = this.transform.parent.transform.GetComponent<AudioSource>();
        this.flag = true;
    }

    // Update is called once per frame
    void Update()
    {

        if (this.start == false) { return; }


        DrawView();
        FindVisibleTargets();

        currentAnimatorInfo = think.GetCurrentAnimatorStateInfo(0);

        //召喚モーション中
        if (currentAnimatorInfo.IsName("Summons") /*&& serch == false*/  )
        {
            //if (currentAnimatorInfo.normalizedTime <= 0.01f)//★多分いらない
            //{
            //    audioSource.clip = audioClips[0];//召喚モーションの音入れる
            //    audioSource.Play();
            //}
            if (currentAnimatorInfo.normalizedTime >= 0.9f)
            {
                MakeTrue("StartMove");
            }
            if (currentAnimatorInfo.normalizedTime >= 0.99f && this.flag)
            {
                //audioSource.clip = audioClips[1];//歩きモーションの音入れる
                //audioSource.loop = true;
                this.flag = false;
                audioSource.Play();
            }
        }

        //歩きモーション中
        if (currentAnimatorInfo.IsName("Walk"))
        {
            //bloodSpray.SetActive(true);
            var direction = transform.forward * Time.deltaTime * speed;
            transform.Translate(direction, Space.World);
        }


        if (FindVisibleTargets() == true)
        {
            //bloodSpray.SetActive(false);
            think.SetBool("ArukiOrOdokashi", true);
            transform.LookAt(playertr);
        }


        //脅かしモーション中
        if (currentAnimatorInfo.IsName("Attack"))
        {
            if (currentAnimatorInfo.normalizedTime <= 0.13f)
            {
                audioSource.clip = audioClips[0];//脅かしモーションの音入れる
                audioSource.loop = false;
                audioSource.Play();
            }
            if (currentAnimatorInfo.normalizedTime >= AttackEffectTime)
            {
                //if (AttackEffect != null)
                //{
                //    AttackEffect.SetActive(true);
                //}
            }

            if (currentAnimatorInfo.normalizedTime >= 1.0f)
            {
                //消滅エフェクト
                deleteEffect.transform.SetParent(null);
                deleteEffect.SetActive(true);
                //0.5秒後にデストロイ
                Destroy(this.gameObject, 1.5f);
            }
        }
    }

    public void MakeTrue(string flag)
    {
        think.SetBool(flag, true);
    }
    public Vector3 DirFromAngle(float angleInDegrees)
    {
        angleInDegrees += transform.eulerAngles.y;
        return new Vector3(Mathf.Sin(angleInDegrees * Mathf.Deg2Rad), 0, Mathf.Cos(angleInDegrees * Mathf.Deg2Rad));
    }

    public void DrawView()
    {
        Vector3 leftBoundary = DirFromAngle(-ViewAngle / 2);
        Vector3 rightBoundary = DirFromAngle(ViewAngle / 2);
        Debug.DrawLine(_transform.position, _transform.position + leftBoundary * ViewDistance, Color.blue);
        Debug.DrawLine(_transform.position, _transform.position + rightBoundary * ViewDistance, Color.blue);
    }

    public bool FindVisibleTargets()
    {
        Collider[] targets = Physics.OverlapSphere(_transform.position, ViewDistance, TargetMask);


        for (int i = 0; i < targets.Length; i++)
        {
            Transform target = targets[i].transform;

            Vector3 dirToTarget = (target.position - _transform.position).normalized;

            if (Vector3.Dot(_transform.forward, dirToTarget) > Mathf.Cos((ViewAngle / 2) * Mathf.Deg2Rad))
            {
                float distToTarget = Vector3.Distance(_transform.position, target.position);

                if (!Physics.Raycast(_transform.position, dirToTarget, distToTarget, ObstacleMask))
                {
                    Debug.DrawLine(_transform.position, target.position, Color.red);
                    return true;
                }
            }
        }
        return false;
    }
}
