﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gizmo : MonoBehaviour {

    public float gizmoSize = 0.3f;
    public Color gizmoColor = Color.yellow;
    float frame;
    bool triggerOn = false;
    GameObject higaisia;
    float turnX;
    float turnZ;

    void Start()
    {
        frame = 0;
        turnX = 80.0f;
        turnZ = -150.0f;
    }

    void Update()
    {
        higaisia = GameObject.FindGameObjectWithTag("Player");
        
        if (triggerOn == true)
        {
            frame += Time.deltaTime *1.0f;
            if (frame <= 0.5)
            {
                this.gameObject.transform.Rotate(turnX * (Time.deltaTime * 1.0f), 0, turnZ * (Time.deltaTime * 1.0f));
            }
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = gizmoColor;
        Gizmos.DrawWireSphere(transform.position, gizmoSize);
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (higaisia.tag == collision.gameObject.tag)
        {
            triggerOn = true;
        }
    }
}
