﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

/*
 * 作成者：         中島龍清
 * 更新日：         2018/09/08
 * 最終更新者：     中島龍清
 * 概要：           サーバ側のキャラクタを操作する
 * アタッチ先：     プレイヤ本体
 * 補足：           speedは15ぐらいが丁度良い？
 */

public class PlayerSController : NetworkBehaviour {

    public float speed;     //速度
    float hori, vert;       //Axisの値保存
    float angle;            //角度
    float camAngle;         //カメラの角度
    float axisVolume;       //スティックの倒している度合

    // Use this for initialization
    void Start()
    {
        this.transform.position = new Vector3(0, 0.5f, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (isServer)
        {
            this.UpdateAxisVolume();
            this.ControllMove();
        }
    }
    //------------------------------------------------------------------------------
    //コントローラによる移動
    void ControllMove()
    {
        //上下左右いずれかにスティックが倒れている場合
        if (this.axisVolume > 0)
        {
            //Fire5(L,R,ZL,ZRボタン)を押している間
            if (Input.GetButton("Fire5") || Input.GetButton("Fire6") || Input.GetAxis("Trigger")!=0)
            {
                //入力に応じて平行移動
                this.Translation();
            }
            //Fire5(LBボタン)を離している間
            else
            {
                //入力に応じて角度を変える
                this.ChangeAngle();
                //進む(倒す度合いにより移動量が変化する)
                this.transform.Translate(Vector3.forward * this.axisVolume * this.speed * Time.deltaTime);
            }
        }
        //スティックを倒していない場合
        else
        {
            //止まる
            this.transform.Translate(Vector3.zero);
        }
    }

    //------------------------------------------------------------------------------
    //各Axisの値を更新
    void UpdateAxisVolume()
    {
        this.hori = Input.GetAxis("Horizontal");
        this.vert = Input.GetAxis("Vertical");
        //スティックの倒している度合を0～1の値で取得する
        //左右の度合い(-1～1)と上下の度合い(-1～1)によって生成される三角形の斜辺を絶対値で出す
        //1以上の値が出た場合は1にする
        this.axisVolume = Mathf.Min(Mathf.Abs(Mathf.Sqrt(this.hori * this.hori + this.vert * this.vert)), 1);
    }
    //------------------------------------------------------------------------------
    //角度の更新
    void UpdateAngle()
    {
        //倒した方向に応じた角度を取得
        this.angle = Mathf.Atan2(this.hori, this.vert);
        //カメラスクリプトを持った子のY軸回転角度を取り出す
        try
        {
            this.camAngle = this.gameObject.GetComponentInChildren<PlayerSCamera>().
                gameObject.transform.eulerAngles.y;
        }
        catch
        {
            this.camAngle = 0;
        }
     }
    //------------------------------------------------------------------------------
    //スティックを倒した方向に応じて角度を変える
    void ChangeAngle()
    {
        this.UpdateAngle();
        //Y軸回転させる（カメラの角度変化に対応）
        this.transform.rotation = Quaternion.Euler(Vector3.up * (this.angle * Mathf.Rad2Deg + this.camAngle));
    }
    //------------------------------------------------------------------------------
    //スティックを倒した方向に応じて平行移動を行う
    void Translation()
    {
        this.UpdateAngle();
        //カメラの角度をラジアンに変換
        float camRad = this.camAngle * Mathf.Deg2Rad;
        //移動用ベクトル
        Vector3 moveVec = new Vector3(Mathf.Sin(this.angle + camRad), 0, Mathf.Cos(this.angle + camRad));
        //向きを変えずに進む(倒す度合いにより移動量が変化する)
        this.transform.position += (moveVec * this.axisVolume * this.speed * Time.deltaTime);
    }
}
