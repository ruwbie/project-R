﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
* 作成者：      ウ
* 更新日：      
* 最終更新者：  
* 概要：        
* アタッチ先：  いぬモデル
* 補足：        
*/
public class Dogbehavior : MonoBehaviour
{


    Animator think;
    GameObject higaisia;
    public bool triggerOn;

    public GameObject deleteEffect;//消滅時のエフェクト

    float Cnt;
    bool flag;
    AudioSource audioSource;//親のオーディオソースを入れる
    public AudioClip[] audioClips;// audioClip複数対応。いらないかな

    void Start()
    {

        Cnt = 0;
        think = this.GetComponent<Animator>();
        //親のオーディオソースの取得
        audioSource = this.transform.parent.transform.GetComponent<AudioSource>();
        think.SetBool("Hoeru", false);
        flag = true;
    }

    void Update()
    {
        higaisia = GameObject.FindGameObjectWithTag("Player");

        if (this.triggerOn == true)
        {
            think.SetBool("Hoeru", true);
            Cnt += Time.deltaTime * 1.0f;

            if (this.flag&&Cnt>1.0f)
            {
                this.flag = false;
                audioSource.clip = audioClips[0];
                audioSource.Play();
            }


            //一定時間でクリーチャー召喚する？
            //cntの値は適当。
            if (Cnt > 2)
            {
                //処刑人動き出す
                GameObject.Find("Execute_model").GetComponent<ExcuteB>().start = true;

            }
            if (Cnt > 7)
            {
                deleteEffect.transform.SetParent(null);
                deleteEffect.SetActive(true);
                //やられる鳴き声入れる？
                audioSource.clip = audioClips[1];
                audioSource.loop = false;
                audioSource.Play();
                Destroy(this.gameObject, 0.5f);
            }
        }
    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == higaisia.tag)
        {
            triggerOn = true;

        }
    }
}
