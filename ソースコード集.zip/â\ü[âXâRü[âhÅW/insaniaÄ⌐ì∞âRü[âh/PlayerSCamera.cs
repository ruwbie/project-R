﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * 作成者：         う
 * 更新日：         10/31
 * 最終更新者：     中島
 * 概要：           サーバ側のカメラを操作する
 * アタッチ先：     サーバ側のカメラ
 * 補足：           addAngleは3ぐらいが丁度良い？
 *                  height,moveRadiusは7ぐらいが丁度良い?
 */

public class PlayerSCamera : MonoBehaviour
{

    float angleY;            //角度
    float angle;
    float hori;       //Axisの値保存、横
    float vert;       //Axisの値保存、縦
    bool Reverse;

    public float addAngle;  //角度の変化割合
    public float height = 7;    //カメラの高さ
    public float moveRadius = 7;  //カメラ回転移動時の半径
    float MAXmoveRadius;
    float MINmoveRadius;
    float MAXheight;
    float MINheight;

    public GameObject ReverseTxt;   //

    // Use this for initialization
    void Start()
    {
        angleY = 0;
        MAXmoveRadius = 12;
        MINmoveRadius = 2;
        MAXheight = 12;
        MINheight = 2;

        this.Reverse = false;
    }

    // Update is called once per frame
    void Update()
    {
        //↓は仮処理なのでとりあえずプレイヤーの後上に固定
        //自身の座標を常にワールド座標変換で更新させる（親に依存させないため）
        //this.transform.position = this.transform.parent.position
        //                        + Vector3.up * 10
        //                        + Vector3.back * 10;

        //自身の回転を常にワールド座標変換で更新させる（親に依存させないため）
        //this.transform.rotation = Quaternion.Euler(45, 0, 0);
        this.GetAxisVolume();
        this.ChangePosition();
        this.ChangeAngle();
    }
    //------------------------------------------------------------------------------
    //スティックの倒し度合を取得
    void GetAxisVolume()
    {
        this.hori = Input.GetAxis("Horizontal2");
        if (this.Reverse == true)
        {
            this.hori = Input.GetAxis("Horizontal2") * -1;
        }
        this.vert = Input.GetAxis("Vertical2");
    }
    //------------------------------------------------------------------------------
    //スティックを倒した方向に応じて角度を変える
    void ChangeAngle()
    {
        //倒した方向、度合に応じて角度を変化させる
        this.angleY = Mathf.Atan2(this.transform.parent.position.x - this.transform.position.x,
                                  this.transform.parent.position.z - this.transform.position.z) * Mathf.Rad2Deg;
        //this.transform.rotation = Quaternion.Euler(Vector3.up * this.angleY);
        this.transform.rotation = Quaternion.Euler(new Vector3(45, this.angleY, 0));
    }
    //------------------------------------------------------------------------------
    //回転するように移動させる
    void ChangePosition()
    {
        this.angle += this.hori * this.addAngle * Time.deltaTime;
        this.height += this.vert * 2 * Time.deltaTime;
        if (this.height >= this.MAXheight)
        {
            this.height = this.MAXheight;
        }
        if (this.height <= this.MINheight)
        {
            this.height = this.MINheight;
        }
        this.moveRadius += this.vert * 2 * Time.deltaTime;
        if (this.moveRadius >= this.MAXmoveRadius)
        {
            this.moveRadius = this.MAXmoveRadius;
        }
        if (this.moveRadius <= this.MINmoveRadius)
        {
            this.moveRadius = this.MINmoveRadius;
        }
        if (Input.GetButtonDown("Modechange"))
        {
            this.Reverse = !this.Reverse;
            this.ReverseTxt.SetActive(true);
            this.ReverseTxt.GetComponent<ReverseText>().vanishFlag = true;
        }
        this.transform.position = this.transform.parent.position +
                                    new Vector3(Mathf.Sin(this.angle) * this.moveRadius,
                                                this.height,
                                                -Mathf.Cos(this.angle) * this.moveRadius);

    }
}
