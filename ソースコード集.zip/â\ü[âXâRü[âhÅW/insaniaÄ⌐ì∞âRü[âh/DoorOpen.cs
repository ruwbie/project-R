﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DoorOpen : MonoBehaviour
{
    GameObject higaisia;
    public bool triggerOn;
    float rotationRate;
    float frame;

    void Start()
    {
        frame = 0;
        rotationRate = 110.0f;
    }
    void Update()
    {
        higaisia = GameObject.FindGameObjectWithTag("Player");
        if (triggerOn == true)
        {
            frame += Time.deltaTime * 1.0f;
            //rotationRate += Time.deltaTime * 0.8f;
            if (frame <= 1.0f)
            {
                this.gameObject.transform.Rotate(0, rotationRate * (Time.deltaTime *1) , 0);
            }
            
        }


    }

    private void OnTriggerEnter(Collider collision)
    {
        if (collision.gameObject.tag == higaisia.tag)
        //if (higaisia)
        {
            triggerOn = true;
        }
    }
}
