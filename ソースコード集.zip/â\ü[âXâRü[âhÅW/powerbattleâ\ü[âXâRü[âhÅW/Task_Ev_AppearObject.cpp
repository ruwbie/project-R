//-------------------------------------------------------------------
//
//-------------------------------------------------------------------
#include  "Task_Ev_AppearObject.h"
//�����Ώۂɂ���^�X�N��include
#include "Task_Enemy00.h"

//================================================================================
BChara::SP AppearObject_BChara(const string& name_)
{
	//����
	BChara::SP w = nullptr;
	if ("Enemy00" == name_) { w = Enemy00::Object::Create(true); }

	return w;
}