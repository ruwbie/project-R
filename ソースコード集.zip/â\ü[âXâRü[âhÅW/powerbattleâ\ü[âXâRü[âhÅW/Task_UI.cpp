//-------------------------------------------------------------------
//
//-------------------------------------------------------------------
#include  "MyPG.h"
#include  "Task_UI.h"
#include  "Task_Player.h"
#include  "easing.h"

namespace  UI
{
	Resource::WP  Resource::instance;
	//-------------------------------------------------------------------
	//���\�[�X�̏�����
	bool  Resource::Initialize()
	{
		this->ICONs = "ICON";
		this->gauges = "gauge";
		this->Outline = "Outline";
		this->Victory = "victory";
		this->Moji = "Moji";
		
		DG::Image_Create(this->ICONs, "./data/image/ICON2.png");
		DG::Image_Create(this->gauges, "./data/image/GAUGES.png");
		DG::Image_Create(this->Outline, "./data/image/Outline.png");
		DG::Image_Create(this->Victory, "./data/image/congratulations.png");
		DG::Image_Create(this->Moji, "./data/image/font_number.png");


		return true;
	}
	//-------------------------------------------------------------------
	//���\�[�X�̉��
	bool  Resource::Finalize()
	{
		DG::Image_Erase(this->ICONs);
		DG::Image_Erase(this->gauges);
		DG::Image_Erase(this->Outline);
		DG::Image_Erase(this->Victory);
		DG::Image_Erase(this->Moji);


		return true;
	}
	//-------------------------------------------------------------------
	//�u�������v�^�X�N�������ɂP�񂾂��s������
	bool  Object::Initialize()
	{
		//�X�[�p�[�N���X������
		__super::Initialize(defGroupName, defName, true);
		//���\�[�X�N���X����or���\�[�X���L
		this->res = Resource::Create();

		//���f�[�^������
		this->render2D_Priority[1] = 0.4f; //�`��̏���
		this->lifeP1 = 1;
		this->lifeP2 = 1;
		this->moveP1 = 0;
		this->moveP2 = 0;
		this->AnimCnt = 0;

		//���^�X�N�̐���

		return  true;
	}
	//-------------------------------------------------------------------
	//�u�I���v�^�X�N���Ŏ��ɂP�񂾂��s������
	bool  Object::Finalize()
	{
		//���f�[�^���^�X�N���


		if (!ge->QuitFlag() && this->nextTaskCreate) {
			//�������p���^�X�N�̐���
		}

		return  true;
	}
	//-------------------------------------------------------------------
	//�u�X�V�v�P�t���[�����ɍs������
	void  Object::UpDate()
	{
		auto player = ge->GetTask_Group_GN <Player::Object>("�v���C��", "Noname");
		for (auto p = player->begin();
			p != player->end();
			++p) {
			if ((*p)->Cameranumber == 1)
			{
				if (this->lifeP1 > 0)
				{
					this->lifeP1 = (float)((*p)->playerLife / 10);
					this->moveP1 = (*p)->moveEnergy;
					if (this->moveP1 <= 0)
					{
						this->moveP1 = 0;
					}
					charaInfoP1 = (*p)->PChara + 1;
					P1shot = (*p)->COMshot;
					P1shotSP = (*p)->SPshot;
				}
				else
				{
					this->lifeP1 = 0;
				}
			}
			else
			{
				if (this->lifeP2 > 0)
				{
					this->lifeP2 = (float)((*p)->playerLife / 10);
					this->moveP2 = (*p)->moveEnergy;
					if (this->moveP2 <= 0)
					{
						this->moveP2 = 0;
					}
					charaInfoP2 = (*p)->PChara + 1;
					P2shot = (*p)->COMshot;
					P2shotSP = (*p)->SPshot;
				}
				else
				{
					this->lifeP2 = 0;
				}
			}
		}
		if (this->lifeP2 <= 0 || this->lifeP1 <=0)
		{
			this->AnimCnt++;
			if (this->AnimCnt > 80)
			{
				this->AnimCnt = 0;
			}
		}
		else if (ge->Iscleared)
		{
			this->AnimCnt++;
			if (this->AnimCnt > 80)
			{
				this->AnimCnt = 0;
			}
		}
		
	}
	//-------------------------------------------------------------------
	//�u�Q�c�`��v�P�t���[�����ɍs������
	void Object::Render(const ML::Box2D& camera_)
	{
		ML::Box2D drawheart(camera_.x + 50, camera_.y + 980, 75, 75);
		ML::Box2D srcheart(0, 0, 300, 300);
		drawheart.Offset(-camera_.x, -camera_.y);
		DG::Image_Draw(this->res->ICONs, drawheart, srcheart);

		ML::Box2D drawmove(camera_.x + 50, camera_.y + 880, 75, 75);
		ML::Box2D srcmove(300, 0, 300, 300);
		drawmove.Offset(-camera_.x, -camera_.y);
		DG::Image_Draw(this->res->ICONs, drawmove, srcmove);

		ML::Box2D drawX((camera_.x + camera_.w) - 220, camera_.y + 900, 35, 35);
		ML::Box2D srcX(25, 18, 15, 15);
		drawX.Offset(-camera_.x, -camera_.y);
		DG::Image_Draw(this->res->Moji, drawX, srcX);

		ML::Box2D drawX2((camera_.x + camera_.w) - 220, camera_.y + 1000, 35, 35);
		ML::Box2D srcX2(25, 18, 15, 15);
		drawX2.Offset(-camera_.x, -camera_.y);
		DG::Image_Draw(this->res->Moji, drawX2, srcX2);

		if (ge->Is1Pmode == false)
		{
			ML::Box2D drawOutline(camera_.x, camera_.y, 960, 1080);
			ML::Box2D srcOutline(0, 0, 300, 300);
			drawOutline.Offset(-camera_.x, -camera_.y);
			DG::Image_Draw(this->res->Outline, drawOutline, srcOutline);
		}

		if (ge->Is1Pmode == true && ge->Iscleared == true && this->lifeP1 >0)
		{
			ML::Box2D drawVsign(0, 0, camera_.w, camera_.h);
			ML::Box2D srcVsign(0, 240 * (this->AnimCnt / 8), 320, 240);
			drawVsign.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Victory, drawVsign, srcVsign);
		}
		

	}
	void  Object::Render2D_AF()
	{
		this->Render(ge->camera2D[0]);
		ML::Box2D drawHPgauge(ge->camera2D[0].x + 150, ge->camera2D[0].y + 1000, (int)this->lifeP2, 25); //�x�����������߂̃L���X�g
		ML::Box2D srcHPgauge(0, 150, 150, 150);
		drawHPgauge.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
		DG::Image_Draw(this->res->gauges, drawHPgauge, srcHPgauge);

		ML::Box2D drawMgauge(ge->camera2D[0].x + 150, ge->camera2D[0].y + 900, (int)this->moveP2, 25); //�x�����������߂̃L���X�g
		ML::Box2D srcMgauge(0, 300, 150, 150);
		drawMgauge.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
		DG::Image_Draw(this->res->gauges, drawMgauge, srcMgauge);

		ML::Box2D drawnormal((ge->camera2D[0].x + ge->camera2D[0].w)- 300, ge->camera2D[0].y + 880, 75, 75);
		ML::Box2D srcnormal(600 * this->charaInfoP2, 0, 300, 300);
		drawnormal.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
		DG::Image_Draw(this->res->ICONs, drawnormal, srcnormal);

		ML::Box2D drawSP((ge->camera2D[0].x + ge->camera2D[0].w) - 300, ge->camera2D[0].y + 980, 75, 75);
		ML::Box2D srcSP(600 * this->charaInfoP2 + 300, 0, 300, 300);
		drawSP.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
		DG::Image_Draw(this->res->ICONs, drawSP, srcSP);

		{
			//===============================================
			ML::Box2D drawremainN10((ge->camera2D[0].x + ge->camera2D[0].w) - 180, ge->camera2D[0].y + 985, 35, 55);
			ML::Box2D srcremainN10((P2shotSP / 10) * 12, 0, 10, 15);
			drawremainN10.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Moji, drawremainN10, srcremainN10);

			ML::Box2D drawremainN((ge->camera2D[0].x + ge->camera2D[0].w) - 150, ge->camera2D[0].y + 985, 35, 55);
			ML::Box2D srcremainN((P2shotSP % 10) * 12, 0, 10, 15);
			drawremainN.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Moji, drawremainN, srcremainN);
		}
		{
			//===============================================
			ML::Box2D drawremainS10((ge->camera2D[0].x + ge->camera2D[0].w) - 180, ge->camera2D[0].y + 885, 35, 55);
			ML::Box2D srcremainS10((P2shot / 10) * 12, 0, 10, 15);
			drawremainS10.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Moji, drawremainS10, srcremainS10);

			ML::Box2D drawremainS((ge->camera2D[0].x + ge->camera2D[0].w) - 150, ge->camera2D[0].y + 885, 35, 55);
			ML::Box2D srcremainS((P2shot % 10) * 12, 0, 10, 15);
			drawremainS.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Moji, drawremainS, srcremainS);
		}

		if (this->lifeP1 <= 0)
		{
			ML::Box2D drawVsign(ge->camera2D[0].x, ge->camera2D[0].y, ge->camera2D[0].w, ge->camera2D[0].h);
			ML::Box2D srcVsign(0, 240 * (this->AnimCnt /8), 320, 240);
			drawVsign.Offset(-ge->camera2D[0].x, -ge->camera2D[0].y);
			DG::Image_Draw(this->res->Victory, drawVsign, srcVsign);
		}


	}
	void  Object::Render2D_BF()
	{
		this->Render(ge->camera2D[1]);
		ML::Box2D drawHPgauge(ge->camera2D[1].x + 150, ge->camera2D[1].y + 1000, (int)this->lifeP1, 25); //�x�����������߂̃L���X�g
		ML::Box2D srcHPgauge(0, 150, 150, 150);
		drawHPgauge.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
		DG::Image_Draw(this->res->gauges, drawHPgauge, srcHPgauge);

		ML::Box2D drawMgauge(ge->camera2D[1].x + 150, ge->camera2D[1].y + 900, (int)this->moveP1, 25); //�x�����������߂̃L���X�g
		ML::Box2D srcMgauge(0, 300, 150, 150);
		drawMgauge.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
		DG::Image_Draw(this->res->gauges, drawMgauge, srcMgauge);

		ML::Box2D drawnormal((ge->camera2D[1].x + ge->camera2D[1].w) - 300, ge->camera2D[1].y + 880, 75, 75);
		ML::Box2D srcnormal(600 * this->charaInfoP1, 0, 300, 300);
		drawnormal.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
		DG::Image_Draw(this->res->ICONs, drawnormal, srcnormal);

		ML::Box2D drawSP((ge->camera2D[1].x + ge->camera2D[1].w) - 300, ge->camera2D[1].y + 980, 75, 75);
		ML::Box2D srcSP(600 * this->charaInfoP1 + 300, 0, 300, 300);
		drawSP.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
		DG::Image_Draw(this->res->ICONs, drawSP, srcSP);
		
		{
			//===============================================
			ML::Box2D drawremainN10((ge->camera2D[1].x + ge->camera2D[1].w) - 180, ge->camera2D[1].y + 985, 35, 55);
			ML::Box2D srcremainN10((P1shotSP / 10) * 12, 0, 10, 15);
			drawremainN10.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
			DG::Image_Draw(this->res->Moji, drawremainN10, srcremainN10);

			ML::Box2D drawremainN((ge->camera2D[1].x + ge->camera2D[1].w) - 150, ge->camera2D[1].y + 985, 35, 55);
			ML::Box2D srcremainN((P1shotSP % 10) * 12, 0, 10, 15);
			drawremainN.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
			DG::Image_Draw(this->res->Moji, drawremainN, srcremainN);
		}
		{
			//===============================================
			ML::Box2D drawremainS10((ge->camera2D[1].x + ge->camera2D[1].w) - 180, ge->camera2D[1].y + 885, 35, 55);
			ML::Box2D srcremainS10((P1shot / 10) * 12, 0, 10, 15);
			drawremainS10.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
			DG::Image_Draw(this->res->Moji, drawremainS10, srcremainS10);

			ML::Box2D drawremainS((ge->camera2D[1].x + ge->camera2D[1].w) - 150, ge->camera2D[1].y + 885, 35, 55);
			ML::Box2D srcremainS((P1shot % 10) * 12, 0, 10, 15);
			drawremainS.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
			DG::Image_Draw(this->res->Moji, drawremainS, srcremainS);
		}
		if (this->lifeP2 <= 0)
		{
			ML::Box2D drawVsign(ge->camera2D[1].x, ge->camera2D[1].y, ge->camera2D[1].w, ge->camera2D[1].h);
			ML::Box2D srcVsign(0, 240 * (this->AnimCnt / 8), 320, 240);
			drawVsign.Offset(-ge->camera2D[1].x, -ge->camera2D[1].y);
			DG::Image_Draw(this->res->Victory, drawVsign, srcVsign);
		}
	}
	


	//������������������������������������������������������������������������������������
	//�ȉ��͊�{�I�ɕύX�s�v�ȃ��\�b�h
	//������������������������������������������������������������������������������������
	//-------------------------------------------------------------------
	//�^�X�N��������
	Object::SP  Object::Create(bool  flagGameEnginePushBack_)
	{
		Object::SP  ob = Object::SP(new  Object());
		if (ob) {
			ob->me = ob;
			if (flagGameEnginePushBack_) {
				ge->PushBack(ob);//�Q�[���G���W���ɓo�^
			}
			if (!ob->B_Initialize()) {
				ob->Kill();//�C�j�V�����C�Y�Ɏ��s������Kill
			}
			return  ob;
		}
		return nullptr;
	}
	//-------------------------------------------------------------------
	bool  Object::B_Initialize()
	{
		return  this->Initialize();
	}
	//-------------------------------------------------------------------
	Object::~Object() { this->B_Finalize(); }
	bool  Object::B_Finalize()
	{
		auto  rtv = this->Finalize();
		return  rtv;
	}
	//-------------------------------------------------------------------
	Object::Object() {	}
	//-------------------------------------------------------------------
	//���\�[�X�N���X�̐���
	Resource::SP  Resource::Create()
	{
		if (auto sp = instance.lock()) {
			return sp;
		}
		else {
			sp = Resource::SP(new  Resource());
			if (sp) {
				sp->Initialize();
				instance = sp;
			}
			return sp;
		}
	}
	//-------------------------------------------------------------------
	Resource::Resource() {}
	//-------------------------------------------------------------------
	Resource::~Resource() { this->Finalize(); }
}