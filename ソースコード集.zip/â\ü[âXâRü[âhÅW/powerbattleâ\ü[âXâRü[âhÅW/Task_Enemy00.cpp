//-------------------------------------------------------------------
//
//-------------------------------------------------------------------
#include  "MyPG.h"
#include  "Task_Enemy00.h"
#include  "randomLib.h"
#include "Task_EF_EnemyDead.h"
namespace  Enemy00
{
	Resource::WP  Resource::instance;
	//-------------------------------------------------------------------
	//���\�[�X�̏�����
	bool  Resource::Initialize()
	{
		this->imagename = "Enemy00Img";
		DG::Image_Create(this->imagename, "./data/image/Enemy00.png");
		return true;
	}
	//-------------------------------------------------------------------
	//���\�[�X�̉��
	bool  Resource::Finalize()
	{
		DG::Image_Erase(this->imagename);
		return true;
	}
	//-------------------------------------------------------------------
	//�u�������v�^�X�N�������ɂP�񂾂��s������
	bool  Object::Initialize()
	{
		//�X�[�p�[�N���X������
		__super::Initialize(defGroupName, defName, true);
		//���\�[�X�N���X����or���\�[�X���L
		this->res = Resource::Create();

		//���f�[�^������
		this->render2D_Priority[1] = 0.6f;

		this->angle_LR = Left;
		this->motion = Stand;
		this->maxSpeed = 2.0f;
		this->addSpeed = 0.7f;
		this->decSpeed = 0.5f;
		this->maxFallSpeed = 10.0f;
		this->jumpPow = -15.0f;
		this->gravity = ML::Gravity(32) * 5;




		//���^�X�N�̐���

		return  true;
	}
	//-------------------------------------------------------------------
	//�u�I���v�^�X�N���Ŏ��ɂP�񂾂��s������
	bool  Object::Finalize()
	{
		//���f�[�^���^�X�N���


		if (!ge->QuitFlag() && this->nextTaskCreate) {
			//�������p���^�X�N�̐���
		}

		return  true;
	}
	//-------------------------------------------------------------------
	//�u�X�V�v�P�t���[�����ɍs������
	void  Object::UpDate()
	{
		this->moveCnt++;
		this->animCnt++;
		this->jumpCnt++;
		this->Think();
		this->Move();
		this->hitbase = ML::Box2D(-30 * (this->Size), -22 * (this->Size), 60 * (this->Size), 44 * (this->Size));
		if (this->unHitTime > 0) { this->unHitTime--; }
		ML::Vec2 est = this->moveVec;
		this->CheckMove(est);

		//�����蔻��
		ML::Box2D me = this->hitbase.OffsetCopy(this->pos);
		auto targets = ge->GetTask_Group_GN <Player::Object>("�v���C��", "Noname");
		for (auto it = targets->begin();
			it != targets->end();
			it++)
		{
			/*this->playerX = (*it)->pos.x;
			this->playerY = (*it)->pos.y;*/

			this->dist = (*it)->pos.x - this->pos.x;

			if ((*it)->CheckHit(me) && this->motion != Bound) //�o�E���h�i��e����Ă���j��Ԃ���Ȃ����̂ݍU������
			{
				BChara::DamageInfo at = { 150,0 };
				(*it)->KnockBack(this, at);
				break;
			}

		}

		if (this->pos.x <= 0)
		{
			this->pos.x = 0;
		}
		if (this->pos.x >= 32 * 180)
		{
			this->pos.x = 32 * 180;
		}
		if (this->playerLife <= 0)
		{
			auto enemyDeadeff = EnemydeadEF::Object::Create(true);
			enemyDeadeff->pos = this->pos;
			
				if (this->reviveCnt > 1)
				{
					for (int i = 0; i < 2; i++)
					{
						/*BChara::DamageInfo at = { 0, 0 };*/
						auto enemy = Enemy00::Object::Create(true);
						enemy->reviveCnt = this->reviveCnt - 1;
						enemy->playerLife = 400 * (enemy->reviveCnt);
						enemy->jumpPow -= (enemy->reviveCnt);
						enemy->maxSpeed += enemy->reviveCnt;
						enemy->Size = this->Size - 1;

						enemy->MaxguardCnt = this->MaxguardCnt - 1;
						enemy->guardCnt = enemy->MaxguardCnt;

						if (i > 0)
						{
							enemy->angle_LR = Right;
							enemy->pos = this->pos;
							enemy->pos.x = this->pos.x + 4;
						}
						else
						{
							enemy->angle_LR = Left;
							enemy->pos = this->pos;
							enemy->pos.x = this->pos.x - 4;
						}
					}
				}
				else
				{
					ge->enemyCnt--;
					if (ge->enemyCnt == 0)
					{
						ge->Iscleared = true;
					}
				}

			

			this->Kill();
		}
	}
	//-------------------------------------------------------------------
	//�u�Q�c�`��v�P�t���[�����ɍs������
	void Object::Render(const ML::Box2D& camera_)
	{
		if (this->unHitTime > 0)
		{
			if ((this->unHitTime / 4) % 2 == 0)
			{
				return; //8�t���[�����S�t���[���͉摜��\�����Ȃ�
			}
		}
		BChara::DrawInfo di = this->Anim();
		di.draw.Offset(this->pos);
		di.draw.Offset(-camera_.x, -camera_.y);
		DG::Image_Draw(this->res->imagename, di.draw, di.src);
	}
	void  Object::Render2D_AF()
	{
		this->Render(ge->camera2D[0]);
	}
	void  Object::Render2D_BF()
	{
		this->Render(ge->camera2D[1]);
	}

	//------------------------------------------------------------------
	//�v�l���󋵔��f�@���[�V��������
	void Object::Think()
	{
		BChara::Motion nm = this->motion;

		switch (nm)
		{
		case Stand:

			if (this->CheckFoot() == false) { nm = Fall; bm = Stand; }
			else { nm = Walk; bm = Stand; }

			break;
		case Walk:

			if (this->CheckFront_LR() == true)
			{
				int rand = GetRandom(0, 4);
				if (rand == 0)
				{
					nm = Turn; bm = Walk;
				}
				else if (rand == 1 || 2)
				{
					nm = Jump; bm = Walk;
				}
			}
			if (this->pos.x <= 0) { nm = Turn; bm = Walk; }
			if (this->pos.x >= (32 * 180)) { nm = Turn; bm = Walk; }
			if (this->CheckFoot() == false) { nm = Fall; bm = Walk; }
			if (this->moveCnt >= 360) { nm = Chase; bm = Walk; }

			break;
		case Jump:
			if (bm == Chase)
			{
				if (this->moveVec.y >= 0) { nm = Fall; bm = Chase; }
				if (this->CheckHead() == true) { nm = Fall; moveVec.y = 0; bm = Chase; }
			}
			else
			{
				if (this->moveVec.y >= 0) { nm = Fall; bm = Jump; }
				if (this->CheckHead() == true) { nm = Fall; moveVec.y = 0; bm = Jump; }
			}
			break;
		case Fall:
			if (bm == Chase && this->CheckFoot() == true)
			{
				nm = Chase; bm = Fall;
			}
			if (this->CheckFoot() == true) { nm = Stand; bm = Fall; }
			break;
		case Attack:
			break;

		case Landing:

			if (this->CheckFoot() == false) { nm = Fall; }
			break;
		case Turn:

			if (this->moveCnt >= 5) { nm = Stand; bm = Turn; }
			break;
		case Chase:
			if (bm == Bound && this->moveCnt >= 200) { nm = Stand; bm = Chase; }
			if (this->moveCnt >= 350) { nm = Stand; bm = Chase; }
			if (this->CheckFront_LR() == true) { nm = Jump; bm = Chase; }
			break;
		case Bound:
			if (this->moveCnt >= 12 && this->CheckFoot() == true)
			{
				nm = Chase; bm = Bound;
			}
			break;

		}
		this->UpdateMotion(nm);
	}

	//-------------------------------------------------------------------
	//���[�V�����ɉ���������
	void Object::Move()
	{
		switch (this->motion) {
		default:
			if (this->moveVec.y < 0 || this->CheckFoot() == false)
			{
				this->moveVec.y = min(this->moveVec.y + this->gravity, this->maxFallSpeed);
			}
			else {
				this->moveVec.y = 0.0f;
			}
			break;
		case Unnon:		break;
		}
		//�ړ����x����
		switch (this->motion)
		{
		default:
			if (this->moveVec.x < 0)
			{
				this->moveVec.x = min(this->moveVec.x + this->decSpeed, 0);
			}
			else
			{
				this->moveVec.x = max(this->moveVec.x - this->decSpeed, 0);
			}
			break;
			//�ړ����x�����𖳌�������K�v�����郂�[�V�����͉���case������
		case Bound:
		case Unnon:		break;
		}
		switch (this->motion)
		{
		case Stand:
			break;
		case Walk:
			if (this->angle_LR == Left)
			{
				this->moveVec.x = max(-this->maxSpeed, this->moveVec.x - this->addSpeed);
			}
			else
			{
				this->moveVec.x = min(+this->maxSpeed, this->moveVec.x + this->addSpeed);
			}
			break;

		case Fall:
			if (this->angle_LR == Left)
			{
				this->moveVec.x = max(-this->maxSpeed, this->moveVec.x - this->addSpeed);
			}
			else
			{
				this->moveVec.x = min(+this->maxSpeed, this->moveVec.x + this->addSpeed);
			}
			break;

		case Jump:
			if (this->angle_LR == Left)
			{
				this->moveVec.x = max(-this->maxSpeed, this->moveVec.x - this->addSpeed);
			}
			else
			{
				this->moveVec.x = min(+this->maxSpeed, this->moveVec.x + this->addSpeed);
			}
			if (this->moveCnt == 0)
			{
				this->moveVec.y = this->jumpPow;
			}
			break;
		case Attack:
			break;
		case Turn:
			if (this->moveCnt == 3) {
				if (this->angle_LR == Left)
				{
					this->angle_LR = Right;
				}
				else
				{
					this->angle_LR = Left;
				}
			}
			break;
		case Chase:
			if (this->dist < 0)
			{
				this->angle_LR = Left;
				this->moveVec.x = max(-this->maxSpeed, this->moveVec.x - this->addSpeed);
			}
			else
			{
				this->angle_LR = Right;
				this->moveVec.x = min(+this->maxSpeed, this->moveVec.x + this->addSpeed);
			}

			{
				//Y���ŌŒ肳���̂�h�~
				if (this->angle_LR == Left && this->dist > -8)
				{
					int rand = GetRandom(0, 1);
					if (rand == 0)
					{
						this->motion = Stand;
					}
					else
					{
						this->motion = Jump;
					}
				}
				else if (this->angle_LR == Right && this->dist < 8)
				{
					int rand = GetRandom(0, 1);
					if (rand == 0)
					{
						this->motion = Stand;
					}
					else
					{
						this->motion = Jump;
					}
				}
			}
			break;
		}
	}

	//-----------------------------------------------------------------------------
	//�A�j���[�V�����̐���

	BChara::DrawInfo Object::Anim()
	{
		ML::Color dc(1, 1, 1, 1);
		ML::Box2D draw1(-32 * (this->Size), -24 * (this->Size), 64 * (this->Size), 48 * (this->Size));
		ML::Box2D draw2(-32 * (this->Size), -24 * (this->Size), 64 * (this->Size), 64 * (this->Size));
		BChara::DrawInfo imageTable[] = {
			{draw1, ML::Box2D(0,0,64,48),dc},			//����1		0
			{draw1, ML::Box2D(64,0,64,48),dc},			//����2		1	
			{draw1, ML::Box2D(0,48,64,64),dc},			//takeoff	2
			{draw1, ML::Box2D(64,48,64,64),dc},			//jump		3
			{draw2, ML::Box2D(128,48,64,64),dc},			//fall		4
			{draw2, ML::Box2D(192,48,80,48),dc},			//land1		5
			{draw2, ML::Box2D(272,48,112,48),dc},		//land2		6
			{draw1, ML::Box2D(0,112,64,64),dc},			//bound		7
		};
		BChara::DrawInfo rtv;

		switch (this->motion)
		{
		default: rtv = imageTable[0];	break;

		case Jump:
			if (this->moveVec.y < -5)
			{
				rtv = imageTable[2];
			}
			else
			{
				rtv = imageTable[3];
			}
			break;
		case Stand: rtv = imageTable[0]; break;
		case Walk:
		case Chase:
			int  walk;
			walk = this->animCnt / 30;
			walk %= 2;
			rtv = imageTable[walk];
			break;
		case Landing:
			rtv = imageTable[5];
			break;
		case Fall: rtv = imageTable[4]; break;
		case Bound: rtv = imageTable[7]; break;
		}
		if (false == this->angle_LR)
		{
			rtv.draw.x = -rtv.draw.x;
			rtv.draw.w = -rtv.draw.w;
		}
		return rtv;
	}

	//=====================================================================================
	void Object::KnockBack(BChara* from_, DamageInfo at_)
	{
		if (this->unHitTime > 0)
		{
			return;
		}

		this->unHitTime = 10;
		this->playerLife -= (at_.pureD + at_.plusD);
		{
			//�X���X�g����Ȃ�
			if (this->guardCnt > 0)
			{
				this->guardCnt--;
				return;
			}
			else if (this->guardCnt == 0)
			{
				this->guardCnt = this->MaxguardCnt;
			}
		}
		if (this->pos.x > from_->pos.x)
		{
			this->moveVec = ML::Vec2(+4, -9);
		}
		else
		{
			this->moveVec = ML::Vec2(-4, -9);
		}
		this->UpdateMotion(Bound);
	}

	//������������������������������������������������������������������������������������
	//�ȉ��͊�{�I�ɕύX�s�v�ȃ��\�b�h
	//������������������������������������������������������������������������������������
	//-------------------------------------------------------------------
	//�^�X�N��������
	Object::SP  Object::Create(bool  flagGameEnginePushBack_)
	{
		Object::SP  ob = Object::SP(new  Object());
		if (ob) {
			ob->me = ob;
			if (flagGameEnginePushBack_) {
				ge->PushBack(ob);//�Q�[���G���W���ɓo�^
			}
			if (!ob->B_Initialize()) {
				ob->Kill();//�C�j�V�����C�Y�Ɏ��s������Kill
			}
			return  ob;
		}
		return nullptr;
	}
	//-------------------------------------------------------------------
	bool  Object::B_Initialize()
	{
		return  this->Initialize();
	}
	//-------------------------------------------------------------------
	Object::~Object() { this->B_Finalize(); }
	bool  Object::B_Finalize()
	{
		auto  rtv = this->Finalize();
		return  rtv;
	}
	//-------------------------------------------------------------------
	Object::Object() {	}
	//-------------------------------------------------------------------
	//���\�[�X�N���X�̐���
	Resource::SP  Resource::Create()
	{
		if (auto sp = instance.lock()) {
			return sp;
		}
		else {
			sp = Resource::SP(new  Resource());
			if (sp) {
				sp->Initialize();
				instance = sp;
			}
			return sp;
		}
	}
	//-------------------------------------------------------------------
	Resource::Resource() {}
	//-------------------------------------------------------------------
	Resource::~Resource() { this->Finalize(); }
}