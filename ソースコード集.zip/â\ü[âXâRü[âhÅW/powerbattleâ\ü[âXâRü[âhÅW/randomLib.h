#pragma once

#include <random>


extern void InitRandom();

int  SubGetRandom(int min_, int max_);
short  SubGetRandom(short min_, short max_);
float  SubGetRandom(float min_, float max_);
double  SubGetRandom(double min_, double max_);

// [min, max]�̈�l�ȗ������擾
template <typename Type> extern  Type GetRandom(Type min_, Type max_){
  Type real_min = static_cast<Type>min(min_, max_);
  Type real_max = static_cast<Type>max(min_, max_);

  return SubGetRandom(real_min, real_max);
}






